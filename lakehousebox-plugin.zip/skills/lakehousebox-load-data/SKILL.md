---
name: lakehousebox-load-data
description: Load data into LakehouseBox tables - CSV, Parquet, GeoParquet or anything DuckDB reads - as one commit per load, append the next batch of files, describe what was loaded, and keep files that are not tables (photos, rasters, archives) in the catalog's file bucket, including from devices that only drop files. Builds on the lakehousebox skill.
---

# Load data into LakehouseBox

The `lakehousebox` skill has the ways in and the general rules; this one is the path from files to tables. It
needs a write credential on the catalog: `lhbox login` (the person ticks write), or the catalog `lhbox new` made
with no account (data writes work before a person claims it).

## First decision: what the person has

| the person has | do | read next |
|---|---|---|
| CSV, Parquet or GeoParquet files on this machine or at an https URL | `lhbox table import <catalog>.<ns>.<table> <file>` | [import](references/import.md) |
| anything else DuckDB reads (JSON, a database attached next to the catalog) | one `CREATE TABLE … AS SELECT` in `lhbox duckdb` | [import](references/import.md), last section |
| files that are not tables: photos, PDFs, rasters, PMTiles, archives | `lhbox file cp <path> lhbox://<catalog>/<prefix>/` (the file bucket, aws s3 style) | [files](references/files.md) |
| a device, relay or partner that only drops files | an upload-only key for one folder | [uploaders](references/uploaders.md) |
| rows that keep arriving (a feed, a webhook, a sensor) | the `lakehousebox-keep-fresh` skill | |

## Import files: the default path

```sh
lhbox table import analytics.sensors.readings 'data/2026/*.parquet'                  # every file, ONE commit
lhbox table import analytics.sensors.readings 'data/2026-10/*.parquet' --mode append  # the next batch, one commit
lhbox table get analytics.sensors.readings                                             # schema, snapshots, rows
```

- **Quote globs**, so `lhbox` expands them and makes one commit; one statement per file is one commit per file.
- **DuckDB 1.5.5 or newer** must be on the machine that holds the files; `lhbox doctor` says which one it found.
- **Creating or appending.** `--mode create` (the default) stops with `table_exists` (exit 2) when the table is there:
  use `--mode append`. Append matches columns by name; a column the files have and the table lacks stops it
  (`columns_not_in_table`) before anything is written.
- **`import_outcome_unknown` (exit 5)**: run `lhbox table get` before anything else. Re-running an append blindly
  writes every row twice.
- **CSV** is detected by its extension. **GeoParquet**: add `--format-version 3` so geometry becomes a typed column
  with its coordinate system, rows in spatial order.
- **Required columns or identifier fields**: create the table first (`lhbox table create … --format-version 3
  --column id:long:required:identifier --column geom:geometry`, see the base skill), then import with `--mode append`.

## Finish: describe what you loaded (required)

A load is not done until the next agent, or the person's colleague, can read the tables without the context you have
now. Do this before you report back, without being asked:

```sh
lhbox table document analytics.sensors.readings --doc "One row per reading, every 5 minutes, from …" \
    --column ts="When the reading was taken (UTC)" --column value="Degrees Celsius"
lhbox catalog agents-md analytics                          # is there one? (it says so when there is none)
lhbox catalog agents-md analytics --set AGENTS.md          # write it, or update it when your load changed what it says
```

- **Every table you created or filled** gets a `--doc` (the grain: one row per what, where the rows come from, how
  fresh) and a `--column` for each column whose meaning is not obvious from its name (units, codes, what null means).
- **The catalog's AGENTS.md**: where to start, the structure, how tables join, analytical caveats, freshness,
  attribution. The template is in the `lakehousebox` skill's agent-setup reference, "Finish: leave notes for the next
  reader". Write what you learned while loading: the traps a reader would otherwise rediscover by querying.
- **Over MCP** (no shell): `document_table` and `set_agents_md` do the same; after a `CREATE TABLE`, `query_rw`'s
  answer names them in `next_step`.

## A load went wrong

Every commit is a snapshot: `lhbox table get` lists them, and an older one can be read or made current again
([time-travel](references/time-travel.md); the rollback is a PyIceberg or Spark call today). Snapshots are kept for a
limited time, so roll back soon. To redo a table's rows, `BEGIN; DELETE FROM t; INSERT INTO t SELECT …; COMMIT;` (one commit, readers never see it
empty; no `CREATE OR REPLACE`); only a schema change needs `DROP TABLE`, then the import again.

## Files that are not tables

The file bucket `<handle>--<catalog>--blobs` takes data files, photos, documents and archives; any other type is
refused with `415 UnsupportedFileType` ([files](references/files.md)). Upload, list, download and delete with the CLI,
written as `aws s3` would be with the catalog side as `lhbox://<catalog>/<key or prefix>` (no aws CLI or boto3; a
large file goes up in parallel parts; JSON on stdout when piped; `s3://` URLs are refused):

```sh
lhbox file cp ./tiles.pmtiles lhbox://garden/public/ --cache-control "public, max-age=86400"
lhbox file cp ./stac lhbox://garden/public/stac/ --recursive --exclude "*.tmp"
lhbox file sync ./exports lhbox://garden/exports/  # only what changed (size and ETag); never deletes
lhbox file ls lhbox://garden/public/
lhbox file cp lhbox://garden/public/tiles.pmtiles .
lhbox file sync lhbox://garden/exports/ ./exports  # down: only what differs here
lhbox file rm lhbox://garden/public/old.pmtiles  # no --yes needed without a terminal
```

`lhbox file put <path> [key] --catalog garden` and `lhbox file get <key> [dest] --catalog garden` are the same as `cp`
up and down. `--metadata a=1,b=2`, `--dryrun`, `--exclude`/`--include` (last match wins) work as in `aws s3`; an aws
flag with no meaning here (`--acl`, `--sse`, `--storage-class`, `sync --delete`, …) is refused with what to use instead.

A device that must only write gets an upload-only key for one folder, which can neither read nor list:

```sh
lhbox catalog uploader create garden --name camera-north --prefix photos/north/ --save ~/camera-north.json
lhbox catalog uploader revoke garden --uploader camera-north
```

## References

- [import](references/import.md): importing in detail: formats, create or append, format version, sort
  order and file size, GeoParquet, the account page's Import dialog, your own SQL.
- [files](references/files.md): what the file bucket takes, the error for the rest, what a public folder serves.
- [uploaders](references/uploaders.md): upload-only keys, folder design, expiring files, the FTP/SFTP drop box.
- [time-travel](references/time-travel.md): snapshots, how long they are kept, reading an older version, rolling back.
